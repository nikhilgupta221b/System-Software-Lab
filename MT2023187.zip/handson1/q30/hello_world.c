#include<stdio.h>

int main(){
	printf("Hello All ! It's lunch time.\n");
	return 0;
}
