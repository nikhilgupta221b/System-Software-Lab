/*
============================================================================
Name : 2.c
Author : Nikhil Gupta
Description : Write a c program to implement infinite loop
Date: 24th Aug, 2023.
============================================================================
*/
#include<stdio.h>
int main(){
	for (;;)
	{}
	return 0;
}
