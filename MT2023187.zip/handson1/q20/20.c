/*
============================================================================
Name : 20.c
Author : Nikhil Gupta
Description : Write a c program to implement infinite loop
Date: Sept 1, 2023.
============================================================================
*/
#include<stdio.h>

int main(){
	for (;;);
	return 0;
}
